(function(){
  const menuToggle = document.getElementById('menuToggle');
  const primaryNav = document.getElementById('primaryNav');
  const themeToggle = document.getElementById('themeToggle');
  const yearEl = document.getElementById('year');
  const copyEmail = document.getElementById('copyEmail');
  const contactForm = document.getElementById('contactForm');

  // Set current year
  yearEl.textContent = new Date().getFullYear();

  // Menu toggle
  menuToggle.addEventListener('click', function(){
    const expanded = this.getAttribute('aria-expanded') === 'true';
    this.setAttribute('aria-expanded', !expanded);
    primaryNav.style.display = expanded ? '' : 'block';
  });

  // Theme toggle
  const current = localStorage.getItem('theme') || 'light';
  if(current === 'dark') document.documentElement.setAttribute('data-theme','dark');
  themeToggle.textContent = current === 'dark' ? 'Light' : 'Dark';

  themeToggle.addEventListener('click', function(){
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    if(isDark){
      document.documentElement.removeAttribute('data-theme');
      localStorage.setItem('theme','light');
      this.textContent = 'Dark';
    } else {
      document.documentElement.setAttribute('data-theme','dark');
      localStorage.setItem('theme','dark');
      this.textContent = 'Light';
    }
  });

  // Copy email
  copyEmail.addEventListener('click', function(){
    const email = 'murugeshwari@example.com';
    navigator.clipboard.writeText(email).then(()=>{
      this.textContent = 'Copied';
      setTimeout(()=> this.textContent = 'Copy email',1300);
    });
  });

  // Form submit
  contactForm.addEventListener('submit', function(e){
    e.preventDefault();
    const fd = new FormData(this);
    const name = fd.get('name');
    const email = fd.get('email');
    const message = fd.get('message');
    if(!name || !email || !message){
      alert('Please fill out all fields.');
      return;
    }
    const subject = encodeURIComponent('Portfolio inquiry from ' + name);
    const body = encodeURIComponent(message + '\n\n— ' + name + ' (' + email + ')');
    window.location.href = `mailto:keerthana@example.com?subject=${subject}&body=${body}`;
  });
})();